from django.apps import AppConfig


class BaseObrConfig(AppConfig):
    name = 'base_obr'
